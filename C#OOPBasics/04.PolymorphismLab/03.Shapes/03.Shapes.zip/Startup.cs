﻿namespace _03.Shapes
{
    public class Startup
    {
        public static void Main()
        {
        }
    }
}