﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _06.FootballTeamGenerator
{
    public class Stat
    {
        private const int MinLevel = 0;
        private const int MaxLevel = 100;

        public Stat(string name, int level)
        {
            this.Name = name;
            this.Level = level;
        }

        private string name;
        private int level;

        public string Name
        {
            get
            {
                return name;
            }

            set
            {
                name = value;
            }
        }

        public int Level
        {
            get
            {
                return level;
            }

            set
            {
                if (value < MinLevel || value > MaxLevel)
                {
                    throw new ArgumentException($"{this.Name} should be between {MinLevel} and {MaxLevel}.");
                }
                level = value;
            }
        }
    }
}
