﻿namespace Emergency_Skeleton.Models.Writers
{
    using System;
    using Emergency_Skeleton.Contracts;
    public class ConsoleWriter : IWriter
    {
        public void WriteLine(string message)
        {
            Console.WriteLine(message);
        }
    }
}