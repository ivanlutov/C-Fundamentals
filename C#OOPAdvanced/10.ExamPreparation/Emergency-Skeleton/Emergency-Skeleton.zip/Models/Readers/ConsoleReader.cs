﻿namespace Emergency_Skeleton.Models.Readers
{
    using System;
    using Emergency_Skeleton.Contracts;
    public class ConsoleReader : IReader
    {
        public string ReadLine()
        {
            return Console.ReadLine();
        }
    }
}