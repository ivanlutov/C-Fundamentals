﻿namespace Emergency_Skeleton.Contracts
{
    public interface IRegistrationTime
    {
        
    }
}