﻿namespace Emergency_Skeleton.Contracts
{
    using Emergency_Skeleton.Enums;
    using Emergency_Skeleton.Utils;

    public interface IEmergency
    {
        string Description { get; }

        EmergencyLevel Level { get; }

        IRegistrationTime Time { get; }

        int GetInfo();
    }
}