﻿namespace Emergency_Skeleton.Contracts
{
    public interface IReader
    {
        string ReadLine();
    }
}